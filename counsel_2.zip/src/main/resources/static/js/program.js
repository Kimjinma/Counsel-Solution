function submitApplication(event) {
    event.preventDefault();  // 폼 기본 제출 동작 방지

    const programInfo = {
        studentNo: document.getElementById('studentNo').value,
        programName: "환경 통계 학습법 특강",
        applyStatus: 'Y',
        engageStatus: 'N',
        approvalStatus: 'N'
    };

    fetch("/counseling/program/apply", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify(programInfo)
    })
        .then(response => {
            if (!response.ok) {
                return response.text().then(text => { throw new Error(text) });
            }
            return response.text();
        })
        .then(result => {
            alert("프로그램 신청이 완료되었습니다.");
            window.location.href = '/counseling/program/group';
        })
        .catch(error => {
            if (error.message.includes('이미 신청한 프로그램입니다')) {
                alert("이미 신청한 프로그램입니다.");
            } else {
                alert("신청 실패: " + error.message);
            }
        });
}