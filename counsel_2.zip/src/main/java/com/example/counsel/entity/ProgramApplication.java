package com.example.counsel.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "PRGRM_PRGRS")
public class ProgramApplication {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "PRGRM_NO", nullable = false)
    private Integer programNo; // 프로그램 번호 (기본 키)

    @Column(name = "EMP_NO", length = 20, nullable = false)
    private String employeeNo = "DEFAULT_EMP"; // 기본값 설정

    @Column(name = "PRGRM_NM", length = 100, nullable = false)
    private String programName; // 프로그램명

    @Column(name = "STDNT_NO", length = 10, nullable = false)
    private String studentNo; // 학번

    @Column(name = "APRV_YN", length = 1, nullable = false)
    private String approvalStatus = "N"; // 기본값 설정 (Y/N)

    @Column(name = "RATING", nullable = true)
    private Integer rating; // 프로그램 평가 (1~5)

    @Column(name = "APPLY_YN", length = 1, nullable = false)
    private String applyStatus = "N"; // 기본값 설정 (Y/N)

    @Column(name = "ENGAGE_YN", length = 1, nullable = false)
    private String engageStatus = "N"; // 기본값 설정 (Y/N)

    // Getters and Setters
    public Integer getProgramNo() {
        return programNo;
    }

    public void setProgramNo(Integer programNo) {
        this.programNo = programNo;
    }

    public String getEmployeeNo() {
        return employeeNo;
    }

    public void setEmployeeNo(String employeeNo) {
        this.employeeNo = employeeNo;
    }

    public String getProgramName() {
        return programName;
    }

    public void setProgramName(String programName) {
        this.programName = programName;
    }

    public String getStudentNo() {
        return studentNo;
    }

    public void setStudentNo(String studentNo) {
        this.studentNo = studentNo;
    }

    public String getApprovalStatus() {
        return approvalStatus;
    }

    public void setApprovalStatus(String approvalStatus) {
        this.approvalStatus = approvalStatus;
    }

    public Integer getRating() {
        return rating;
    }

    public void setRating(Integer rating) {
        this.rating = rating;
    }

    public String getApplyStatus() {
        return applyStatus;
    }

    public void setApplyStatus(String applyStatus) {
        this.applyStatus = applyStatus;
    }

    public String getEngageStatus() {
        return engageStatus;
    }

    public void setEngageStatus(String engageStatus) {
        this.engageStatus = engageStatus;
    }
}
