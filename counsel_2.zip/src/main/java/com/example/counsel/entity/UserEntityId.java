package com.example.counsel.entity;

import java.io.Serializable;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode
public class UserEntityId implements Serializable {
    private String id;        // USER_NO
    private String userSe;    // USER_SE
    private String lgnId;     // LGN_ID

    // 기본 생성자
    public UserEntityId() {}

    // getters and setters
}