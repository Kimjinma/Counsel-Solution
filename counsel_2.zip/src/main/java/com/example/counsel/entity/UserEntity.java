package com.example.counsel.entity;


import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.sql.Timestamp;

@Getter
@Setter
@Entity
@Table(name = "user_info")
@IdClass(UserEntityId.class)
public class UserEntity {

    @Id
    @Column(name = "USER_NO", length = 10)
    private String id;

    @Id
    @Column(name = "USER_SE", length = 10)
    private String userSe;

    @Id
    @Column(name = "LGN_ID", length = 100)
    private String lgnId;

    @Column(name = "PSWD", length = 512)
    private String password;

    @Column(name = "PSWD_CHG_DT")
    private Timestamp pswdChgDt;  // 추가

    @Column(name = "PSWD_ERR_NMTN")
    private Integer pswdErrNmtn = 0;  // 비밀번호 오류 횟수

    @Column(name = "LAST_LGN_DT")
    private Timestamp lastLgnDt;  // 마지막 로그인 시간

    @Column(name = "SOCIAL_ID", length = 100)
    private String socialId;

    @Column(name = "ACCESS_TOKEN", length = 100)
    private String accessToken;

    @Column(name = "REFRESH_TOKEN", length = 100)
    private String refreshTkoen;

    @Column(name = "email")
    private String email;

    @Column(name = "name")
    private String name;

    @Column(name = "phone")
    private String phone;

    @Column(name = "role")
    private String role;

    @Column(name = "username")
    private String username;

    public void setSocialId(String s) {
    }

    public void setAccessToken(String s) {
    }

    public void setRefreshToken(String s) {
    }

    // getters and setters
}