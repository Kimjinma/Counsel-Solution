package com.example.counsel.controller;

import com.example.counsel.dto.JoinDTO;
import com.example.counsel.service.JoinService;
import com.example.counsel.service.PasswordResetService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/auth")  // 인증 관련 URL을 /auth로 시작하도록 변경
public class AuthController {

    private final JoinService joinService;
    private final PasswordResetService passwordResetService;

    @Autowired
    public AuthController(JoinService joinService, PasswordResetService passwordResetService) {
        this.joinService = joinService;
        this.passwordResetService = passwordResetService;
    }

    // 로그인 페이지
    @GetMapping("/login")
    public String loginPage() {
        return "login";
    }

    // 회원가입 페이지
    @GetMapping("/join")
    public String joinPage() {
        return "join";
    }

    @PostMapping("/loginProc")
    public String loginProcess() {
        // 로그인 처리는 Spring Security가 담당
        return "redirect:/";
    }

    // 회원가입 처리
    @PostMapping("/join")
    public ResponseEntity<?> joinProcess(@RequestBody JoinDTO joinDTO) {
        try {
            if (joinDTO.getPassword() == null || joinDTO.getPassword().trim().isEmpty()) {
                return ResponseEntity.badRequest().body("비밀번호는 필수 입력값입니다.");
            }

            System.out.println("Joining user: " + joinDTO.getUsername());
            joinService.joinProcess(joinDTO);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    // 로그아웃 처리
    @GetMapping("/logout")
    public String logout(HttpServletRequest request, HttpServletResponse response) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null) {
            new SecurityContextLogoutHandler().logout(request, response, authentication);
        }
        return "redirect:/";
    }

    // 비밀번호 재설정 페이지
    @GetMapping("/reset-password")
    public String resetPasswordPage() {
        return "reset-password";
    }

    // 비밀번호 재설정 처리
    @PostMapping("/reset-password")
    public String handleResetPassword(@RequestParam String email, Model model) {
        boolean success = passwordResetService.resetPassword(email);
        if (success) {
            model.addAttribute("message", "임시 비밀번호가 이메일로 전송되었습니다.");
        } else {
            model.addAttribute("error", "해당 이메일로 등록된 사용자가 없습니다.");
        }
        return "reset-password";
    }
}