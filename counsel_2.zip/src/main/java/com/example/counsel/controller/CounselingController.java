package com.example.counsel.controller;

import com.example.counsel.dto.AdviceRequest;
import com.example.counsel.dto.ProgramApplicationDTO;
import com.example.counsel.entity.StudentInfo;
import com.example.counsel.service.AdviceService;
import com.example.counsel.service.ProgramApplicationService;
import com.example.counsel.repository.StudentInfoRepository;
import com.example.counsel.service.StudentInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping("/counseling")
public class CounselingController {

    private final AdviceService adviceService;
    private final ProgramApplicationService applicationService;
    private final StudentInfoRepository studentInfoRepository;
    private final StudentInfoService studentInfoService;  // 추가

    @Autowired
    public CounselingController(
            AdviceService adviceService,
            ProgramApplicationService applicationService,
            StudentInfoRepository studentInfoRepository,
            StudentInfoService studentInfoService) {    // 생성자에 추가
        this.adviceService = adviceService;
        this.applicationService = applicationService;
        this.studentInfoRepository = studentInfoRepository;
        this.studentInfoService = studentInfoService;  // 초기화
    }

    // 페이지 매핑
    @GetMapping("/center")
    public String centerPage() {
        return "center";
    }

    @GetMapping("/advice/person")
    public String advicePersonPage() {
        return "advice-person";
    }

    @GetMapping("/advice/professor")
    public String adviceProfessorPage() {
        return "advice-professor"; // 교수/학습 상담 페이지
    }

    @GetMapping("/advice/job")
    public String adviceJobPage() {
        return "advice-job"; // 취업/진로 상담 페이지
    }

    @GetMapping("/program/group")
    public String programGroupPage() {
        return "program-group";
    }

    @GetMapping("/program/group-plus")
    public String programGroupPlusPage(Model model, Authentication authentication) {
        if (authentication != null && authentication.isAuthenticated()) {
            String lgnId = authentication.getName();
            model.addAttribute("loginId", lgnId);

            StudentInfo studentInfo = studentInfoRepository.findByLgnId(lgnId);
            if (studentInfo == null) {
                // 학생 정보가 없으면 자동 생성
                studentInfoService.createStudentInfoForExistingUser(lgnId);
                studentInfo = studentInfoRepository.findByLgnId(lgnId);
            }

            if (studentInfo != null) {
                model.addAttribute("studentInfo", studentInfo);
                model.addAttribute("studentNo", studentInfo.getStudentNo());
                boolean isApplied = applicationService.isAlreadyApplied(
                        studentInfo.getStudentNo(),
                        "환경 통계 학습법 특강"
                );
                model.addAttribute("isApplied", isApplied);
            } else {
                // studentInfo가 null인 경우 로그 추가
                System.out.println("Warning: StudentInfo not found for user: " + lgnId);
            }
        }

        // 프로그램 정보 추가
        Map<String, Object> program = new HashMap<>();
        program.put("id", "ENV_STAT_01");
        program.put("name", "환경 통계 학습법 특강");
        model.addAttribute("program", program);

        return "program-group-plus";
    }



    // API 엔드포인트
    @PostMapping("/api/advice/submit")
    public ResponseEntity<Map<String, String>> submitAdvice(@RequestBody AdviceRequest request) {
        boolean isSubmitted = adviceService.processAdvice(request);
        Map<String, String> response = new HashMap<>();

        if (isSubmitted) {
            response.put("status", "success");
            response.put("message", "신청 완료");
            return ResponseEntity.ok(response);
        } else {
            response.put("status", "error");
            response.put("message", "신청 실패");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }
    }

    @PostMapping("/program/apply")
    @ResponseBody
    public ResponseEntity<String> apply(@RequestBody ProgramApplicationDTO applicationDTO) {
        try {
            applicationService.saveApplication(applicationDTO);
            return ResponseEntity.ok("신청 성공");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("신청 실패: " + e.getMessage());
        }
    }
}