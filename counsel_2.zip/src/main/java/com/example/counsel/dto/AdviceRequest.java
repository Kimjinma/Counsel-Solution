package com.example.counsel.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@lombok.Data
public class AdviceRequest {
    private String question1;
    private String question2;
    private String question3;
    private String schedule;

    // Getter, Setter
}
