package com.example.counsel.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProgramApplicationDTO {
    private String studentNo; // 학번
    private String programName; // 프로그램명
    private String applyStatus; // 신청 여부 (Y/N)
    private String engageStatus; // 참여 여부 (Y/N)
    private String approvalStatus; // 승인 상태 (Y/N)
    private Integer rating; // 프로그램 평가 (1~5)
    private String employeeNo; // 교직원 번호

    // Getters and Setters
    public String getStudentNo() {
        return studentNo;
    }

    public void setStudentNo(String studentNo) {
        this.studentNo = studentNo;
    }

    public String getProgramName() {
        return programName;
    }

    public void setProgramName(String programName) {
        this.programName = programName;
    }

    public String getApplyStatus() {
        return applyStatus;
    }

    public void setApplyStatus(String applyStatus) {
        this.applyStatus = applyStatus;
    }

    public String getEngageStatus() {
        return engageStatus;
    }

    public void setEngageStatus(String engageStatus) {
        this.engageStatus = engageStatus;
    }

    public String getApprovalStatus() {
        return approvalStatus;
    }

    public void setApprovalStatus(String approvalStatus) {
        this.approvalStatus = approvalStatus;
    }

    public Integer getRating() {
        return rating;
    }

    public void setRating(Integer rating) {
        this.rating = rating;
    }

    public String getEmployeeNo() {
        return employeeNo;
    }

    public void setEmployeeNo(String employeeNo) {
        this.employeeNo = employeeNo;
    }
}
