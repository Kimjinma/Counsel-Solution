package com.example.counsel.repository;

import com.example.counsel.entity.UserEntity;
import com.example.counsel.entity.UserEntityId;
import org.springframework.data.jpa.repository.JpaRepository;


public interface UserRepository extends JpaRepository<UserEntity, UserEntityId> {

    boolean existsByUsername(String username);

    UserEntity findByLgnId(String lgnId);
    boolean existsByLgnId(String lgnId);

    UserEntity findByUsername(String username);

    UserEntity findByEmail(String email);
}
