package com.example.counsel.repository;

import com.example.counsel.entity.ProgramApplication;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProgramApplicationRepository extends JpaRepository<ProgramApplication, Long> {
    boolean existsByStudentNoAndProgramName(String studentNo, String programName);
}