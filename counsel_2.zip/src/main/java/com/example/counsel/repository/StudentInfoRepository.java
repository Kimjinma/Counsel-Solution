package com.example.counsel.repository;

import com.example.counsel.entity.StudentInfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface StudentInfoRepository extends JpaRepository<StudentInfo, String> {
    @Query("SELECT s FROM StudentInfo s WHERE s.lgnId = :lgnId")
    StudentInfo findByLgnId(@Param("lgnId") String lgnId);
}