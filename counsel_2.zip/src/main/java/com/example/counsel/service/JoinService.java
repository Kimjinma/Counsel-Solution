package com.example.counsel.service;

import com.example.counsel.dto.JoinDTO;
import com.example.counsel.entity.UserEntity;
import com.example.counsel.entity.StudentInfo;
import com.example.counsel.repository.UserRepository;
import com.example.counsel.repository.StudentInfoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;

@Service
public class JoinService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private StudentInfoRepository studentInfoRepository;

    @Autowired
    private PasswordEncoder bCryptPasswordEncoder;

    @Transactional
    public String joinProcess(JoinDTO joinDTO) {
        UserEntity user = new UserEntity();
        String userNo = generateUserNo();
        user.setId(userNo);
        user.setUserSe("STUDENT");
        user.setLgnId(joinDTO.getUsername());
        user.setUsername(joinDTO.getUsername());
        user.setPassword(bCryptPasswordEncoder.encode(joinDTO.getPassword()));
        user.setEmail(joinDTO.getEmail());
        user.setName(joinDTO.getName());
        user.setPhone(joinDTO.getPhone());
        user.setRole("ROLE_USER");
        user.setPswdChgDt(new Timestamp(System.currentTimeMillis()));
        user.setPswdErrNmtn(0);
        user.setLastLgnDt(new Timestamp(System.currentTimeMillis()));

        // NOT NULL 컬럼들 초기화
        user.setSocialId("");
        user.setAccessToken("");    // 빈 문자열로 초기화
        user.setRefreshToken("");

        user = userRepository.save(user);

        try {
            // 2. StudentInfo 생성 및 저장
            StudentInfo studentInfo = new StudentInfo();
            studentInfo.setStudentNo(generateStudentNo());
            studentInfo.setStudentName(joinDTO.getName());
            studentInfo.setEmail(joinDTO.getEmail());
            studentInfo.setMobilePhoneNumber(joinDTO.getPhone());
            studentInfo.setLgnId(joinDTO.getUsername());
            studentInfo.setUserNo(userNo);  // USER_NO 설정

            // NOT NULL 컬럼들에 대한 기본값 설정
            studentInfo.setAddress("");
            studentInfo.setDetailAddress("");
            studentInfo.setZipCode("");

            studentInfoRepository.save(studentInfo);

            return null;
        } catch (Exception e) {
            throw new RuntimeException("회원가입 실패: " + e.getMessage());
        }
    }

    private String generateStudentNo() {
        return "2024" + String.format("%05d", (int)(Math.random() * 100000));
    }

    private String generateUserNo() {
        return "U" + String.format("%09d", (int)(Math.random() * 1000000000));
    }
}