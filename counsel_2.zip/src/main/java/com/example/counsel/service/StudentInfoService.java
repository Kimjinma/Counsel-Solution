package com.example.counsel.service;

import com.example.counsel.entity.StudentInfo;
import com.example.counsel.entity.UserEntity;
import com.example.counsel.repository.StudentInfoRepository;
import com.example.counsel.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class StudentInfoService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private StudentInfoRepository studentInfoRepository;

    @Transactional
    public void createStudentInfoForExistingUser(String username) {
        UserEntity user = userRepository.findByUsername(username);
        if (user != null && studentInfoRepository.findByLgnId(username) == null) {
            StudentInfo studentInfo = new StudentInfo();
            studentInfo.setStudentNo(generateStudentNo());
            studentInfo.setStudentName(user.getName());
            studentInfo.setEmail(user.getEmail());
            studentInfo.setMobilePhoneNumber(user.getPhone());
            studentInfo.setLgnId(user.getUsername());
            studentInfo.setUserNo(String.valueOf(user.getId()));
            studentInfoRepository.save(studentInfo);
        }
    }

    private String generateStudentNo() {
        return "2024" + String.format("%05d", (int)(Math.random() * 100000));
    }
}