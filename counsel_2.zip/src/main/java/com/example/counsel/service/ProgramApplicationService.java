package com.example.counsel.service;

import com.example.counsel.dto.ProgramApplicationDTO;
import com.example.counsel.entity.ProgramApplication;
import com.example.counsel.repository.ProgramApplicationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProgramApplicationService {

    private final ProgramApplicationRepository repository;

    @Autowired
    public ProgramApplicationService(ProgramApplicationRepository repository) {
        this.repository = repository;
    }

    public void saveApplication(ProgramApplicationDTO applicationDTO) {
        // 중복 신청 체크
        if (repository.existsByStudentNoAndProgramName(
                applicationDTO.getStudentNo(),
                applicationDTO.getProgramName())) {
            throw new RuntimeException("이미 신청한 프로그램입니다.");

        }

        ProgramApplication application = new ProgramApplication();
        application.setStudentNo(applicationDTO.getStudentNo());
        application.setProgramName(applicationDTO.getProgramName());
        application.setApplyStatus(applicationDTO.getApplyStatus() != null ? applicationDTO.getApplyStatus() : "N");
        application.setEngageStatus(applicationDTO.getEngageStatus() != null ? applicationDTO.getEngageStatus() : "N");
        application.setApprovalStatus(applicationDTO.getApprovalStatus() != null ? applicationDTO.getApprovalStatus() : "N");
        application.setRating(applicationDTO.getRating());
        application.setEmployeeNo(applicationDTO.getEmployeeNo() != null ? applicationDTO.getEmployeeNo() : "DEFAULT_EMP");

        repository.save(application);
    }

    public boolean isAlreadyApplied(String studentNo, String programName) {
        return repository.existsByStudentNoAndProgramName(studentNo, programName);
    }
}